package br.com.barravi.teste_bluetooth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
